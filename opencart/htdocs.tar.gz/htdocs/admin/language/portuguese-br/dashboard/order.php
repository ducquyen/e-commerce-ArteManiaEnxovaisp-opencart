<?php
// Heading
$_['heading_title'] = 'Total de pedidos';

// Text
$_['text_view']     = 'Ver mais...';