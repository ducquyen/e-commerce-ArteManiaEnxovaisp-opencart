<?php
// Heading
$_['heading_title']				= 'Obrigado por fazer compras com %s .... ';

// Text
$_['text_title']				= 'Cartão de crédito ou débito (PayPoint)';
$_['text_response']				= 'Resposta do PayPoint:';
$_['text_success']				= '... seu pagamento foi recebido com sucesso.';
$_['text_success_wait']			= '<b><span style="color: #FF0000">Aguarde...</span></b> Enquanto nós terminamos de processar seu pedido.<br>Se você não for redirecionado automaticamente em 10 segundos, clique <a href="%s">aqui</a>.';
$_['text_failure']				= '... seu pagamento foi cancelado com sucesso!';
$_['text_failure_wait']			= '<b><span style="color: #FF0000">Aguarde...</span></b><br>Se você não for redirecionado automaticamente em 10 segundos, clique <a href="%s">aqui</a>.';