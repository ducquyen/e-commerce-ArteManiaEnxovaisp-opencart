<?php
$_['text_credit']   = 'Crédito na loja';
$_['text_order_id'] = 'Pedido nº: #%s';