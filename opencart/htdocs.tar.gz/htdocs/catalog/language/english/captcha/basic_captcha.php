<?php
// Heading
$_['heading_title'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Enter the code in the box below';

// Error
$_['error_captcha'] = 'Verification code does not match the image!';
