<?php
// Heading
$_['heading_title'] = 'Utilizar vale presentes';

// Text
$_['text_success']  = 'O vale presentes foi utilizado com sucesso!';

// Entry
$_['entry_voucher'] = 'Código do vale presentes';

// Error
$_['error_voucher'] = 'Atenção: O vale presentes é inválido ou já foi utilizado!';
$_['error_empty']   = 'Atenção: Digite o código do vale presentes!';